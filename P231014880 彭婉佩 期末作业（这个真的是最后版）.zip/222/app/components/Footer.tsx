'use client';

import WakaTimeStats from './WakaTimeStats';

export default function Footer() {
  return (
    <footer className="relative z-20 mt-16">
      <div className="absolute inset-0 bg-gradient-to-t from-kuromi-purple/80 to-transparent"></div>
      <div className="container mx-auto py-8 px-6 relative">
        <div className="flex flex-col items-center">
          <div className="mb-6 w-32 h-32 relative flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-kuromi-pink/10 to-transparent rounded-full"></div>
            <div className="absolute inset-4 border border-kuromi-pink/20 rounded-full"></div>
            <div className="text-3xl text-kuromi-dark font-bold tracking-widest">Kuromi</div>
          </div>
          
          <p className="text-kuromi-dark text-lg mb-2 tracking-wide">
            试试推开虚掩的门，霉味和光会一起涌出来。
          </p>
          
          <div className="flex space-x-4 text-sm text-kuromi-dark my-4">
            <span>可爱</span>
            <span>•</span>
            <span>顽皮</span>
            <span>•</span>
            <span>小恶魔</span>
          </div>

          <div className="text-kuromi-dark/70 text-sm mt-4">
            <WakaTimeStats />
          </div>
          
          <p className="text-kuromi-dark/70 text-sm mt-2">&copy; {new Date().getFullYear()} - Life is a journey, enjoy the ride.</p>
        </div>
      </div>
    </footer>
  );
} 