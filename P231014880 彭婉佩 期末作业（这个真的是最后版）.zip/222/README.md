# 💜 Kuromi's Playground - 库洛米的秘密基地

欢迎来到库洛米的秘密基地！这是一个基于 Next.js 构建的、充满可爱与小恶魔风格的 Web 应用，也是一个《Web 前端开发》的课程练习项目。

在这里，你可以翻阅本小姐的"杰作"，或者在 AI 聊天室里陪我聊聊天。整个网站都采用了本小姐最喜欢的淡紫色卡通风格，还有动态背景轮播哦！

## ✨ 主题与特点

- **💜 库洛米主题**: 整个网站从配色、字体到文本内容，都充满了库洛米风格。
- **🎨 动态背景**: 使用两张库洛米背景图，实现了平滑的淡入淡出轮播效果。
- **📱 响应式设计**: 无论是在电脑还是手机上，都能获得良好的视觉体验。
- **😈 可爱文案**: 所有的文本都经过精心设计，符合库洛米有点"小恶魔"的人设。
- **🤖 QAnything 大模型集成**: 对接了 QAnything API，实现了一个完全定制化的智能问答机器人。
- **⏱️ WakaTime 集成**: 调用 WakaTime API，在页脚实时显示总编码时长。

## 🚀 主要功能

### 1. 练习清单 (`/portfolio`)

- **集中展示**: 以卡片列表的形式，展示了本学期所有的课程练习。
- **在线预览**: 每个练习都可以直接点击，在 `<iframe>` 中进行在线预览和操作。

### 2. AI 聊天 (`/qanything`)

- **定制界面**: 一个完全定制化的聊天机器人界面。
- **流式响应**: 对接 QAnything API，可以与"酷"AI 进行实时对话，并支持流式响应。
- **引用来源**: AI 的回答会附带引用来源，让你知道它的回答基于哪些"秘密卷宗"。

## 🛠️ 技术栈

- **框架**: [Next.js](https://nextjs.org/) (使用 App Router)
- **语言**: [TypeScript](https://www.typescriptlang.org/)
- **样式**: [Tailwind CSS](https://tailwindcss.com/)
- **UI 组件**: [Arco Design](https://arco.design/)
- **API**:
  - [WakaTime API](https://wakatime.com/developers)
  - [QAnything API](https://qanything.ai/)

## 📂 项目结构

```
/final-project
├── app/
│   ├── components/       # 共享组件 (Header, Footer, WakaTimeStats)
│   ├── portfolio/        # 练习清单页面及子路由
│   │   └── [assignment]/
│   │       └── page.tsx
│   ├── qanything/        # AI 聊天页面
│   │   └── page.tsx
│   ├── api/              # 后端 API 路由 (代理对外部 API 的请求)
│   ├── layout.tsx        # 全局布局
│   └── page.tsx          # 应用首页
├── public/               # 静态资源 (图片, 练习的 html 文件等)
├── .env.local            # 环境变量 (存储 API Keys)
├── README.md             # 就是你正在看的这个文件啦！
└── ...                   # 其他 Next.js 配置文件
```

## 😈 QAnything 对接小秘密

**选择路径**: 进阶路径 (Advanced Path)

**原因**:
为了能完全控制 AI 聊天室的样子，我才不要用别人现成的界面呢！自己从零开始设计和开发，才能更好地掌握 API 对接、前端状态管理和异步操作。这不仅能满足课程的最高要求，也是一个把学到的东西全都用上的好机会！

**实现细节**:
- **前端界面**: 在 `/app/qanything` 路径下，用 React 和 Tailwind CSS 搭建了一个超可爱的聊天界面。
- **API 代理**: 在后端的 API 路由 (`/app/api/qanything`) 中处理对 QAnything API 的请求。这样做是为了把我的 API Key 藏起来，不能让你们发现！
- **状态管理**: 使用 `useState` 和 `useEffect` 来管理聊天记录、加载状态和可能出现的各种小意外。
- **流式输出**: 为了让你感觉像真的在和我聊天，我实现了打字机一样的流式输出效果。

## ⏱️ WakaTime 时长统计魔法

1.  去 [WakaTime Settings](https://wakatime.com/settings/api-key) 拿到你自己的 API Key。
2.  把它填在 `.env.local` 文件的 `WAKATIME_API_KEY` 变量里。
3.  在后端创建了一个 API 路由，专门用来获取 WakaTime 数据，这样 API Key 就不会在浏览器里暴露啦。
4.  最后，在页脚组件里调用这个接口，展示总练习时长。

## 本地开发指南

想在你的电脑上运行这个项目吗？按下面的步骤来吧！

1.  **克隆仓库**
    ```bash
    git clone https://github.com/your-username/your-repo-name.git
    cd your-repo-name
    ```

2.  **安装依赖**
    ```bash
    npm install
    ```

3.  **设置环境变量**
    在项目根目录下创建一个名为 `.env.local` 的文件，然后把下面的内容复制进去。别忘了替换成你自己的 API 密钥哦！
    ```env
    # WakaTime API Key (从 https://wakatime.com/settings/api-key 获取)
    WAKATIME_API_KEY="YOUR_WAKATIME_API_KEY"

    # QAnything API Key (或其他大模型服务的Key)
    QANYTHING_API_KEY="YOUR_QANYTHING_API_KEY"
    YOUDAO_AGENT_STREAM_API_URL="YOUR_AGENT_API_URL"
    ```

4.  **运行开发服务器**
    ```bash
    npm run dev
    ```

    现在，在浏览器里打开 [http://localhost:3000](http://localhost:3000) 就可以看到啦！

## 📸 作业截屏

*等我化个妆，拍几张美美的照片就放上来！*
Qanything截图 2025-07-07 141433.png
链接: https://pan.baidu.com/s/1iLgtO00HBYqO2S0PzAl3vg?pwd=36we 提取码: 36we 
wakatime截图 2025-07-02 091730.png
链接: https://pan.baidu.com/s/1p3ACtG6xLCE35q-rvfAeWA?pwd=mwf6 提取码: mwf6 
屏幕截图 2025-07-02 091654.png
链接: https://pan.baidu.com/s/1s9XaOZz-I-Bt5xlf1lvYXw?pwd=sjis 提取码: sjis 

## 🐙 GitHub 仓库管理

本项目所有代码和文档均通过 Git 进行版本控制，并托管在公共 GitHub 仓库中。我的每一次 Commit 都写得清清楚楚，才不会像某些人一样乱写呢！

---

感谢你的访问，希望你喜欢本小姐的秘密基地！
