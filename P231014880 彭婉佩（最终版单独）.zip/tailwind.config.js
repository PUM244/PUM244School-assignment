/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  corePlugins: {
    preflight: false, // 禁用 Tailwind 的基础样式重置，以避免与 Arco Design 冲突
  },
  theme: {
    extend: {
      colors: {
        'kuromi-purple': '#E6E6FA', // 一个柔和的淡紫色
        'kuromi-dark': '#3a2d4b',
        'kuromi-pink': '#ffb6c1',
      },
      backgroundImage: {
        'kuromi-1': "url('/background/5996ee1bcf6ba61d7148243b7424cfc.jpg')",
        'kuromi-2': "url('/background/fbf109bebb36f75f4a0ac30a6cf1d4f.jpg')",
      },
      animation: {
        slideshow: 'slideshow 10s ease-in-out infinite',
      },
      keyframes: {
        slideshow: {
          '0%, 100%': {
            backgroundImage: "url('/background/5996ee1bcf6ba61d7148243b7424cfc.jpg')",
          },
          '50%': {
            backgroundImage: "url('/background/fbf109bebb36f75f4a0ac30a6cf1d4f.jpg')",
          },
        },
      },
    },
  },
  plugins: [],
}; 