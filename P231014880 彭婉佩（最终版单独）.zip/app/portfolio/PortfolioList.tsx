'use client';

import Link from 'next/link';
import { List, Card, Typography, Space, Tag, Divider } from '@arco-design/web-react';

type Assignment = {
  filename: string;
  name: string;
};

type PortfolioListProps = {
  assignments: Assignment[];
  error?: boolean;
};

export default function PortfolioList({ assignments, error }: PortfolioListProps) {
  if (error) {
    return (
        <div className="flex items-center justify-center p-4 sm:p-6 md:p-8">
            <div className="w-full max-w-md p-6 sm:p-8 bg-kuromi-purple/70 rounded-2xl backdrop-blur-xl border-2 border-kuromi-pink/30 shadow-2xl shadow-kuromi-dark/20">
                <div className="bg-white/50 p-8 rounded-lg">
                    <Typography.Title heading={3} style={{ color: '#3a2d4b' }}>练习清单</Typography.Title>
                    <Typography.Paragraph style={{ color: '#d946ef' }}>加载练习列表失败，是网络波动了吗？</Typography.Paragraph>
                </div>
            </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-md p-6 sm:p-8 bg-kuromi-purple/70 rounded-2xl backdrop-blur-xl border-2 border-kuromi-pink/30 shadow-2xl shadow-kuromi-dark/20">
        <Typography.Title heading={2} style={{ color: '#3a2d4b', textAlign: 'center', marginBottom: '1.5rem' }}>
          练习清单
        </Typography.Title>
        
        <Divider className="my-4 border-kuromi-pink/20" />
        
        {assignments.length > 0 ? (
          <List
            className="custom-scrollbar"
            style={{ maxHeight: 'calc(100vh - 22rem)', overflow: 'auto' }}
            dataSource={assignments}
            render={(assignment, index) => (
              <List.Item key={assignment.filename} style={{ padding: 0, marginBottom: '0.75rem', border: 'none' }}>
                <Link href={`/portfolio/${assignment.filename}`} style={{ display: 'block', width: '100%' }}>
                  <Card
                    className="group transition-all duration-300 transform hover:scale-[1.02]"
                    style={{ 
                      background: 'linear-gradient(to right, rgba(255, 255, 255, 0.8), rgba(230, 230, 250, 0.9))',
                      border: '2px solid rgba(255, 182, 193, 0.8)',
                      borderRadius: '0.5rem'
                    }}
                    hoverable
                  >
                    <Space direction="vertical" style={{ width: '100%' }}>
                      <Typography.Title heading={5} style={{ color: '#3a2d4b', margin: 0 }}>
                        {assignment.name}
                      </Typography.Title>
                      <Typography.Paragraph style={{ color: '#3a2d4b', opacity: 0.8, margin: '0.25rem 0 0.5rem' }}>
                        点开看看，这可是本小姐的杰作！
                      </Typography.Paragraph>
                      <div>
                        <Tag color="magenta" bordered={false}>练习</Tag>
                      </div>
                    </Space>
                  </Card>
                </Link>
              </List.Item>
            )}
          />
        ) : (
          <Card style={{ background: 'rgba(255, 255, 255, 0.5)', border: '2px dashed rgba(255, 182, 193, 0.6)' }}>
            <Typography.Title heading={4} style={{ color: '#3a2d4b', textAlign: 'center' }}>空空如也</Typography.Title>
            <Typography.Paragraph style={{ color: '#3a2d4b', opacity: 0.8, textAlign: 'center' }}>
              这里什么都还没有呢，快去添加一些练习吧！
            </Typography.Paragraph>
          </Card>
        )}
      </div>
    </div>
  );
} 