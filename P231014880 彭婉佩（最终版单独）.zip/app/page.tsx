'use client';

import Link from 'next/link';
import { Button, Card, Space, Typography, Divider } from '@arco-design/web-react';

export default function Home() {
  return (
    <div className="flex justify-center items-center">
      <div className="max-w-3xl w-full relative">
        {/* 外层装饰框 */}
        <div className="absolute inset-0 -m-2 border border-kuromi-pink/20 rounded-lg"></div>
        <div className="absolute inset-0 -m-4 border border-kuromi-pink/10 rounded-xl"></div>
        
        {/* 主内容 */}
        <div className="text-center bg-kuromi-purple/60 p-10 rounded-lg backdrop-blur-xl border border-kuromi-pink/30 shadow-2xl shadow-kuromi-dark/10">
          {/* 上部装饰 */}
          <div className="flex justify-center mb-6">
            <div className="w-24 h-1 bg-gradient-to-r from-transparent via-kuromi-pink/50 to-transparent"></div>
          </div>
          
          <h1 className="text-4xl sm:text-5xl font-bold mb-8 text-kuromi-dark" style={{ fontFamily: "'Noto Serif SC', serif" }}>
            捣蛋就现在！
          </h1>
          
          <p className="text-lg text-kuromi-dark max-w-2xl mx-auto font-semibold leading-relaxed">
            哼，别以为我看起来很乖，我可是酷酷的库洛米！
          </p>
          
          <p className="mt-4 text-kuromi-dark/80 max-w-xl mx-auto">
            这里是我的秘密基地，你可以看看我的"杰作"，或者陪我聊聊天。
          </p>
          
          <Divider className="my-8 border-kuromi-pink/20" />
          
          <div className="grid md:grid-cols-2 gap-8">
            <Card
              className="relative overflow-hidden h-48 flex flex-col justify-end group border-kuromi-pink/40"
              bordered={false}
              style={{
                backgroundImage: `url('/background/5996ee1bcf6ba61d7148243b7424cfc.jpg')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent transition-all duration-500 group-hover:from-black/80"></div>
              <div className="relative p-6 text-left text-white">
                <Typography.Title heading={5} className="!text-white">
                  过往练习
                </Typography.Title>
                <Typography.Paragraph className="!text-gray-200">
                  这里存放着我所有的练习项目，快来围观！
                </Typography.Paragraph>
                <div className="flex justify-end mt-2">
                  <Link href="/portfolio">
                    <Button type="primary" className="!bg-kuromi-pink/80 hover:!bg-kuromi-pink !border-kuromi-dark/20">
                      查看杰作
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
            
            <Card
              className="relative overflow-hidden h-48 flex flex-col justify-end group border-kuromi-pink/40"
              bordered={false}
              style={{
                backgroundImage: `url('/background/fbf109bebb36f75f4a0ac30a6cf1d4f.jpg')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent transition-all duration-500 group-hover:from-black/80"></div>
              <div className="relative p-6 text-left text-white">
                <Typography.Title heading={5} className="!text-white">
                  AI 聊天
                </Typography.Title>
                <Typography.Paragraph className="!text-gray-200">
                  想找人聊天吗？本小姐随时奉陪，快来！
                </Typography.Paragraph>
                <div className="flex justify-end mt-2">
                  <Link href="/qanything">
                    <Button type="primary" className="!bg-kuromi-pink/80 hover:!bg-kuromi-pink !border-kuromi-dark/20">
                      开始聊天
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          </div>
          
          {/* 下部装饰 */}
          <div className="flex justify-center mt-8">
            <div className="w-16 h-1 bg-gradient-to-r from-transparent via-kuromi-pink/30 to-transparent"></div>
          </div>
          
          {/* 角落装饰 */}
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-kuromi-pink/30 -translate-x-1 -translate-y-1"></div>
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-kuromi-pink/30 translate-x-1 -translate-y-1"></div>
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-kuromi-pink/30 -translate-x-1 translate-y-1"></div>
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-kuromi-pink/30 translate-x-1 translate-y-1"></div>
        </div>
      </div>
    </div>
  );
}
